<?php
/**
 * Created by PhpStorm.
 * User: mvielmetter
 * Date: 17.11.17
 * Time: 15:17
 */

namespace Ph2\Publications\Model;


class AbstractModel
{
    /**
     * @var string
     */
    private $dbhost = "mysql.ph2.uni-koeln.de";

    /**
     * @var string
     */
    private $dbname = "bib_db";

    /**
     * @var string
     */
    private $dbuser = "bib_db";

    /**
     * @var string
     */
    private $dbpass = "NvA8BSDJUaLn8hMH";//TODO delete

    /**
     * @var \PDO
     */
    protected $db = NULL;

    /**
     * AbstractModel constructor.
     *
     * Creates an uplink to the foreign database
     */
    public function __construct()
    {
        $this->getDbConfig();

        $this->db = new \PDO(
            'mysql:dbname=' . $this->dbname . ';host=' . $this->dbhost, $this->dbuser, $this->dbpass
        );
    }

    /**
     * Stores the Typo3 config for the plugin in this class
     */
    protected function getDbConfig()
    {

    }

    /**
     * @param array $array
     *
     * @return array
     */
    protected function quoteArray($array)
    {
        foreach ($array as $key => $value) {
            $array[$key] = $this->db->quote($value);
        }

        return $array;
    }

    /**
     * @param string $string
     *
     * @return string
     */
    protected function quoteCommaString($string)
    {
        if (empty($string)) {
            return $string;
        }
        $string = explode(',', $string);

        return implode(',', $this->quoteArray($string));
    }

    /**
     * @param mixed  $string
     * @param string $prepareTitle
     *
     * @return string
     */
    protected function likePrepareSql($data, $prepareTitle)
    {
        if (is_string($data)) {
            $data = explode(',', $data);
        } elseif (!is_iterable($data)) {
            return '';
        }
        $strings = $this->quoteArray($data);
        foreach ($strings as $i => $string) {
            $strings[$i] = "$prepareTitle LIKE %$string%";
        }

        return '(' . implode(' OR ', $strings) . ')';
    }
}