<?php
if (!defined('TYPO3_MODE')) {
    die ('Access denied.');
}

\FluidTYPO3\Flux\Core::registerProviderExtensionKey('Ph2.Publications', 'File');
\FluidTYPO3\Flux\Core::registerProviderExtensionKey('Ph2.Publications', 'Page');
\FluidTYPO3\Flux\Core::registerProviderExtensionKey('Ph2.Publications', 'Content');


